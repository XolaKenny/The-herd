import re
import pandas as pd
import pyttsx3
from sklearn import preprocessing
from sklearn.tree import DecisionTreeClassifier, _tree
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.svm import SVC
import csv
import warnings

warnings.filterwarnings("ignore", category=DeprecationWarning)

# Load data
training = pd.read_csv('Data/Training.csv')
testing = pd.read_csv('Data/Testing.csv')
cols = training.columns[:-1]
x = training[cols]
y = training['prognosis']
reduced_data = training.groupby(training['prognosis']).max()

# Mapping strings to numbers
le = preprocessing.LabelEncoder()
le.fit(y)
y = le.transform(y)

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.33, random_state=42)
testx = testing[cols]
testy = le.transform(testing['prognosis'])

# Decision Tree Classifier
clf = DecisionTreeClassifier().fit(x_train, y_train)
print("Decision Tree Score:", cross_val_score(clf, x_test, y_test, cv=3).mean())

# SVM Classifier
model = SVC().fit(x_train, y_train)
print("SVM Score:", model.score(x_test, y_test))

# Voice output setup
def readn(text):
    engine = pyttsx3.init()
    engine.setProperty('voice', "english+f5")
    engine.setProperty('rate', 130)
    engine.say(text)
    engine.runAndWait()
    engine.stop()

# Load dictionaries
severityDictionary = {}
description_list = {}
precautionDictionary = {}
symptoms_dict = {symptom: index for index, symptom in enumerate(x)}

# Function to load data into dictionaries
def getSeverityDict():
    global severityDictionary
    with open('MasterData/symptom_severity.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        for row in csv_reader:
            if len(row) >= 2:
                try:
                    severityDictionary[row[0].strip()] = int(row[1].strip())
                except ValueError:
                    print(f"Error processing row {row}")

def getDescription():
    global description_list
    with open('MasterData/symptom_Description.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        for row in csv_reader:
            description_list[row[0]] = row[1]

def getprecautionDict():
    global precautionDictionary
    with open('MasterData/symptom_precaution.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        for row in csv_reader:
            precautionDictionary[row[0]] = row[1:]

# Function to calculate condition severity
def calc_condition(exp, days):
    total_severity = sum(severityDictionary.get(item, 0) for item in exp)
    result = "You should take the consultation from a doctor." if (total_severity * days) / (len(exp) + 1) > 13 else "It might not be that bad, but you should take precautions."
    print(result)
    readn(result)

# Recursive function to traverse the decision tree
def tree_to_code(tree, feature_names):
    tree_ = tree.tree_
    feature_name = [feature_names[i] if i != _tree.TREE_UNDEFINED else "undefined!" for i in tree_.feature]
    chk_dis = ",".join(feature_names).split(",")
    symptoms_present = []

    while True:
        disease_input = input("Enter the symptom you are experiencing -> ").replace(' ', '_')
        conf, cnf_dis = check_pattern(chk_dis, disease_input)
        if conf:
            for num, it in enumerate(cnf_dis):
                print(f"{num}) {it}")
            conf_inp = int(input(f"Select the one you meant (0 - {len(cnf_dis) - 1}): ")) if len(cnf_dis) > 1 else 0
            disease_input = cnf_dis[conf_inp]
            break
        else:
            print("Enter a valid symptom.")

    num_days = int(input("For how many days? : "))

    def recurse(node, depth):
        indent = "  " * depth
        if tree_.feature[node] != _tree.TREE_UNDEFINED:
            name = feature_name[node]
            threshold = tree_.threshold[node]
            val = 1 if name == disease_input else 0
            if val <= threshold:
                recurse(tree_.children_left[node], depth + 1)
            else:
                symptoms_present.append(name)
                recurse(tree_.children_right[node], depth + 1)
        else:
            present_disease = print_disease(tree_.value[node])
            symptoms_exp = [syms for syms in reduced_data.columns[reduced_data.loc[present_disease].values[0].nonzero()]]
            for syms in symptoms_exp:
                inp = input(f"{syms}? (yes/no) : ").strip().lower()
                if inp == "yes":
                    symptoms_exp.append(syms)
            second_prediction = sec_predict(symptoms_exp)
            calc_condition(symptoms_exp, num_days)
            diagnosis = f"You may have {present_disease[0]} or {second_prediction[0]}" if present_disease[0] != second_prediction[0] else f"You may have {present_disease[0]}"
            print(diagnosis)
            readn(diagnosis)
            print(description_list.get(present_disease[0], "No description available."))
            precautions = precautionDictionary.get(present_disease[0], ["No precautions listed."])
            for i, precaution in enumerate(precautions):
                print(f"{i + 1}) {precaution}")

    recurse(0, 1)

# Helper functions
def check_pattern(dis_list, inp):
    regexp = re.compile(f"{inp}")
    pred_list = [item for item in dis_list if regexp.search(item)]
    return (1, pred_list) if pred_list else (0, [])


# Secondary prediction using symptoms
def sec_predict(symptoms_exp):
    df = pd.read_csv('Data/Training.csv')
    X = df.iloc[:, :-1]
    y = df['prognosis']

    # Split data into training and testing sets correctly
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=20)

    # Fit the DecisionTreeClassifier with the training data
    rf_clf = DecisionTreeClassifier()
    rf_clf.fit(X_train, y_train)

    # Map symptoms to indices in the training data
    symptoms_dict = {symptom: index for index, symptom in enumerate(X.columns)}
    input_vector = np.zeros(len(symptoms_dict))
    for item in symptoms_exp:
        if item in symptoms_dict:
            input_vector[symptoms_dict[item]] = 1

    # Predict the disease based on symptoms
    prediction = rf_clf.predict([input_vector])
    return prediction


def print_disease(node):
    node = node[0]
    val = node.nonzero()
    disease = le.inverse_transform(val[0])
    return list(map(str.strip, list(disease)))

# Main function execution
getSeverityDict()
getDescription()
getprecautionDict()
name = input("Your Name? -> ")
print(f"Hello, {name}")
tree_to_code(clf, cols)
